package com.nt.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nt.entity.EProduct;
import com.nt.service.IEProductService;

import jakarta.servlet.http.HttpSession;

@Controller
public class MainController {
	
	@Autowired
	private IEProductService service;
	
	
	@GetMapping("/")
	public String home(Map<String, Object> map) {
		List<EProduct> list = service.getAllDetails();
		map.put("list", list);
		return "home";
	}
	
	@GetMapping("add")
	public String addPage(@ModelAttribute("pro")EProduct pro) {
		return "add";
	}
	
	@PostMapping("add")
	public String addPagePost(@ModelAttribute("pro")EProduct pro,HttpSession ses) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
	    pro.setDateAdded(dtf.format(now));
		String addRecord = service.addRecord(pro);
		ses.setAttribute("resultMsg", addRecord);
		return "redirect:./";
	}
	
	@GetMapping("edit1")
	public String updatePage(@ModelAttribute("pro")EProduct pro,@RequestParam("id")int id) {
		EProduct emlementsById = service.getEmlementsById(id);
		BeanUtils.copyProperties(emlementsById, pro);
		return "edit";
	}
	
	@PostMapping("edit1")
	public String editPagePost(@ModelAttribute("pro")EProduct pro,HttpSession ses) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
	    pro.setDateUpdated(dtf.format(now));
		String upRecord = service.updateRecord(pro);
		ses.setAttribute("resultMsg", upRecord);
		return "redirect:./";
	}
	
	@GetMapping("delete")
	public String deletePagePost(@RequestParam("id")int id,HttpSession ses) {
		String deleteById = service.deleteById(id);
		ses.setAttribute("resultMsg", deleteById);
		return "redirect:./";
	}
	

}

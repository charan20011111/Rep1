package com.nt.service;

import java.util.List;

import com.nt.entity.EProduct;

public interface IEProductService {
	
	List<EProduct> getAllDetails();
	public String addRecord(EProduct prod);
	public EProduct getEmlementsById(int id);
	public String updateRecord(EProduct prod);
	public String deleteById(int id);


}

package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.EProduct;
import com.nt.repository.IEProductRepo;

@Service
public class EProductServiceImpl implements IEProductService {
	@Autowired
	private IEProductRepo repo;

	@Override
	public List<EProduct> getAllDetails() {
		return repo.findAll();
	}

	@Override
	public String addRecord(EProduct prod) {
		return "Id "+repo.save(prod).getId()+" is Successfully Inserted to the Table";
	}

	@Override
	public EProduct getEmlementsById(int id) {
		return repo.findById(id).get();
	}

	@Override
	public String updateRecord(EProduct prod) {
		return "Id "+repo.save(prod).getId()+" is Successfully Updated in the Table";
	}

	@Override
	public String deleteById(int id) {	
		repo.deleteById(id);
		return "Id "+id+" is Successfully Deleted from the Table";
	}

}

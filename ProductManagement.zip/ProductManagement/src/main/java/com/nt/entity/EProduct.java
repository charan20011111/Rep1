package com.nt.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="eproduct")
public class EProduct {
	
	@Id
	@SequenceGenerator(name="pr",sequenceName = "pro",initialValue = 1000,allocationSize = 1)
	@GeneratedValue(generator = "pr",strategy = GenerationType.TABLE)
	private int id;
	private String name;
	private float price;
	private String dateAdded;
	private String dateUpdated;
	
	

	public EProduct() {
		super();
	}

	public EProduct(int id, String name, float price, String dateAdded) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.dateAdded = dateAdded;
	}

	public String getDateUpdated() {
		return dateUpdated;
	}

	public void setDateUpdated(String dateUpdated) {
		this.dateUpdated = dateUpdated;
	}

	public EProduct(String dateUpdated) {
		super();
		this.dateUpdated = dateUpdated;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getDateAdded() {
		return dateAdded;
	}

	public void setDateAdded(String dateAdded) {
		this.dateAdded = dateAdded;
	}

	@Override
	public String toString() {
		return "EProduct [id=" + id + ", name=" + name + ", price=" + price + ", dateAdded=" + dateAdded
				+ ", dateUpdated=" + dateUpdated + "]";
	}
	
	

}
